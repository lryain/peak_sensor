# MySensors_MyDevices
my own MySensors devices 

Etwas mehr dazu noch hier:<br>
http://www.s6z.de/cms/index.php/homeautomation/mysensors/63-up-bewegungsmelder-in-eigenbau<br>
http://www.s6z.de/cms/index.php/homeautomation/mysensors/66-mysensors-up-sensor-platine<br>
http://www.s6z.de/cms/index.php/homeautomation/mysensors/67-up-sensor-pir-temp-hum-lux-in-eigenbau<br>
