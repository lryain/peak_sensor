# MysensorsATSHA_EEprom


A simple breadboard with :
- ATSHA204A SOT23 authentication footprint (ATSHA204A-STUCZ-T)
- Eeprom for OTA (AT25DF512C-SSHN-B)




