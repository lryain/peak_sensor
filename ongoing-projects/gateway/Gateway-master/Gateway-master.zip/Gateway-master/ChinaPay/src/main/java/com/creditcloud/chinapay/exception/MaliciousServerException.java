package com.creditcloud.chinapay.exception;

public class MaliciousServerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8629071465213317481L;
    public MaliciousServerException(String message) {
        super(message);
    }
}
