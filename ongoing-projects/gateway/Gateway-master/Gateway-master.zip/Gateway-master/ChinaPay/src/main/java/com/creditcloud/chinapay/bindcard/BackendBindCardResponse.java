/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.chinapay.bindcard;

import com.creditcloud.model.BaseObject;

/**
 * 后台页面认证绑卡response
 *
 * @author rooseek
 */
public class BackendBindCardResponse extends BaseObject {

    private static final long serialVersionUID = 20150311L;

}
