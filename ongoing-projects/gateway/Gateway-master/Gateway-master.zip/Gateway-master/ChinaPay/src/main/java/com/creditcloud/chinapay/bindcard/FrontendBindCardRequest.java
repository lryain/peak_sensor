/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.chinapay.bindcard;

/**
 * 前台页面认证绑卡request
 *
 * @author rooseek
 */
public class FrontendBindCardRequest {

    private static final long serialVersionUID = 20150311L;

}
