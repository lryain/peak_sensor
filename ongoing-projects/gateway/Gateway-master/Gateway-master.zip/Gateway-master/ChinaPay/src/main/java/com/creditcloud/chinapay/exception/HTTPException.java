package com.creditcloud.chinapay.exception;

public class HTTPException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -880871181518322810L;

    public HTTPException(String message) {
        super(message);
    }
}
