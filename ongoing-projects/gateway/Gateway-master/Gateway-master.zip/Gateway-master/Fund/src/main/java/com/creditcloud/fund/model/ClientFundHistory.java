/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.fund.model;

/**
 * p2p平台资金历史记录，以天为单位
 *
 * @author rooseek
 */
public class ClientFundHistory {
}
