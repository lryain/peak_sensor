/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.config.enums;

/**
 * 图片,文档存储提供商
 *
 * @author rooseek
 */
public enum StorageProvider {

    /**
     * 本地
     */
    Local,
    /**
     * upyun
     */
    UpYun,
    /**
     * 凤凰
     */
    Feng,
}
