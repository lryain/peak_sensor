/**
 * 与批量处理相关的接口
 */
package com.creditcloud.batch;
