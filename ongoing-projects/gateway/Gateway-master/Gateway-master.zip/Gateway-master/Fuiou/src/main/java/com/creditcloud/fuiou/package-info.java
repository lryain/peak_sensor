/**
 * 富友代收付平台相关的服务
 */
package com.creditcloud.fuiou;
