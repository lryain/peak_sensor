/**
 * 生成各类合同相关的接口
 */
package com.creditcloud.contract;
