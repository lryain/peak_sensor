/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.email;

/**
 *
 * @author rooseek
 */
public interface EmailConstants {

    long CONFIRM_INTERVAL = 60 * 60 * 1000;//milliseconds
}
