/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.creditcloud.cms;

/**
 *
 * @author rooseek
 */
public interface CMSConstant {

    String DEFAULT_ARTICLE_URL = "/cms/article";

    String DEFAULT_CHANNEL_URL = "/cms/channel";

    int MAX_ARTICLE_CONTENT = 4000;

}
