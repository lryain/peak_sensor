/**
 * Common classes for the creditcloud services
 */
package com.creditcloud.common;
