# Sensebender-Micro-with-Si7021-Breakoutboard
Clone of the <a href="https://github.com/mysensors/SensebenderMicro">original SenseBender Micro Board</a> but using the Si7021 on a breakout board.

This repository contains a clone of the original Sensebender Micro board from  -> <a href="http://www.mysensors.org">Mysensors</a>

As I find it hard to solder the used Si7021 I decided to exchange it with a breakout variant. Those are available for actually less money than the chip itself on Aliexpress or ebay. Just search for Si7021.

However - as I'm a totally newbie to Eagle, this is a work in progress. So be aware that it is not finished yet and needs some testing. :)

