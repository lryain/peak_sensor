/** Automatically generated file. DO NOT MODIFY */
package ru.smoluks.android.bluetoothlegatt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}