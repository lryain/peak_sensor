package com.appyware.dimmer.models;

/**
 * Created by
 * --Vatsal Bajpai on
 * --22/08/16 at
 * --8:33 PM
 */
public class ActivityEvent {

    public int dimValue;

    public ActivityEvent(int dimValue) {
        this.dimValue = dimValue;
    }
}
