package com.appyware.dimmer.models;

/**
 * Created by
 * --Vatsal Bajpai on
 * --22/08/16 at
 * --8:33 PM
 */
public class ServiceEvent {

    public String name;

    public ServiceEvent(String name) {
        this.name = name;
    }
}
