# Dimmer - Eyes Protector
Dimmer's job is to soothe your dazzled eyes by reducing device brightness lower than the minimum in dark.

# Download
<a href='https://play.google.com/store/apps/details?id=com.appyware.dimmer&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png' width="161" height="62"/></a>

# Screenshots

<a><img alt='' src='https://lh3.googleusercontent.com/eROfyE2m14zjOcqp27Y72f3Aa8FVUVmxysNj9Z5-BffLB7evJw5vcQKKdlexWFFAy3Q=h900' width="587" height="657"/></a>
<a><img alt='' src='https://lh3.googleusercontent.com/CSHfCS4rUGRmLNwKBra-hiBCKVuFt6NV2WAN2cZ6Ooz_sqVBWjIt8UbTNmOI08BQhTpb=h900-rw' width="587" height="657"/></a>
<a><img alt='' src='https://lh3.googleusercontent.com/cS-460wMEEkB421q0TauiVweVn0N9F8LKzeP-1XfsZovEwojqbHkemhXKLl8oGH98AE=h900-rw' width="587" height="657"/></a>
