I want to present the next device in the series MDMS called MDMSNode "Lighting".This device is intended for home lighting control.The device has the ability to install one of the popular radios - nRF24L01 (2.4GHz) or RFM69HW (433-868-915MHz). Triac BT137S is installed for the load control in the device. The small size of the device (73mm x 32mm x 15mm) allows to embed it directly into the lamps, floor lamps, chandeliers, etc. 

Features:
  - Atmega328P;
  - ATSHA204A;
  - ACS712-5A;
  - HLK-PM01;
  - RFM69HW or nRF24L01;
  - BTS137S;
  - MOC3043;
  - M25P40.
    
