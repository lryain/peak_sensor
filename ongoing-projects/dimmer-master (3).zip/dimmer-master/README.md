# dimmer
Arduino timerless AC dimmer
Works well on ATMEGA8 
