Energy Monitor Shield P3 is an Arduino-compatible expansion card designed for building energy monitoring system with LCD screen and an interface for connecting the wireless transceiver nRF24L01 +.
 
Connect up to three sensors AC (30-100A)

Support for LCD Screen Nokia LCD5110

Turn off the LCD backlight with a jumper

Two buttons to control (operate one analog pin)

Interface to connect the transceiver to 2.4G nRF24L01 +

GROVE-compatible connector: I2C

Fully compatible with Ethernet Shield